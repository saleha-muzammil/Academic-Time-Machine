/* Main Simulation File */
#include "Pendulum_model.h"

#define prefixedName_performSimulation Pendulum_performSimulation
#define prefixedName_updateContinuousSystem Pendulum_updateContinuousSystem
#include <simulation/solver/perform_simulation.c>

#define prefixedName_performQSSSimulation Pendulum_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c>

/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;
#if defined(__cplusplus)
extern "C" {
#endif

int Pendulum_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Pendulum_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Pendulum_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Pendulum_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Pendulum_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/*
 equation index: 10
 type: SIMPLE_ASSIGN
 y = L * cos(theeta)
 */
void Pendulum_eqFunction_10(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,10};
  data->localData[0]->realVars[8] /* y variable */ = (data->simulationInfo->realParameter[0] /* L PARAM */) * (cos(data->localData[0]->realVars[1] /* theeta STATE(1,temp) */));
  TRACE_POP
}
/*
 equation index: 11
 type: SIMPLE_ASSIGN
 x = L * sin(theeta)
 */
void Pendulum_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  data->localData[0]->realVars[7] /* x variable */ = (data->simulationInfo->realParameter[0] /* L PARAM */) * (sin(data->localData[0]->realVars[1] /* theeta STATE(1,temp) */));
  TRACE_POP
}
/*
 equation index: 12
 type: SIMPLE_ASSIGN
 Torque = 0.5 * M * g * x
 */
void Pendulum_eqFunction_12(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,12};
  data->localData[0]->realVars[5] /* Torque variable */ = (0.5) * ((data->simulationInfo->realParameter[1] /* M PARAM */) * ((data->simulationInfo->realParameter[2] /* g PARAM */) * (data->localData[0]->realVars[7] /* x variable */)));
  TRACE_POP
}
/*
 equation index: 13
 type: SIMPLE_ASSIGN
 temp1 = DIVISION(-Torque, J)
 */
void Pendulum_eqFunction_13(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,13};
  data->localData[0]->realVars[6] /* temp1 variable */ = DIVISION_SIM((-data->localData[0]->realVars[5] /* Torque variable */),data->localData[0]->realVars[4] /* J variable */,"J",equationIndexes);
  TRACE_POP
}
/*
 equation index: 14
 type: SIMPLE_ASSIGN
 der(temp) = temp1
 */
void Pendulum_eqFunction_14(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,14};
  data->localData[0]->realVars[2] /* der(temp) STATE_DER */ = data->localData[0]->realVars[6] /* temp1 variable */;
  TRACE_POP
}
/*
 equation index: 15
 type: SIMPLE_ASSIGN
 der(theeta) = temp
 */
void Pendulum_eqFunction_15(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,15};
  data->localData[0]->realVars[3] /* der(theeta) STATE_DER */ = data->localData[0]->realVars[0] /* temp STATE(1,temp1) */;
  TRACE_POP
}


int Pendulum_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
  
  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  Pendulum_functionLocalKnownVars(data, threadData);
  Pendulum_eqFunction_10(data, threadData);

  Pendulum_eqFunction_11(data, threadData);

  Pendulum_eqFunction_12(data, threadData);

  Pendulum_eqFunction_13(data, threadData);

  Pendulum_eqFunction_14(data, threadData);

  Pendulum_eqFunction_15(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Pendulum_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Pendulum_symEulerUpdate(DATA *data, modelica_real dt)
{
  return -1;
}



/* forwarded equations */
extern void Pendulum_eqFunction_11(DATA* data, threadData_t *threadData);
extern void Pendulum_eqFunction_12(DATA* data, threadData_t *threadData);
extern void Pendulum_eqFunction_13(DATA* data, threadData_t *threadData);
extern void Pendulum_eqFunction_14(DATA* data, threadData_t *threadData);
extern void Pendulum_eqFunction_15(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  Pendulum_eqFunction_11(data, threadData);

  Pendulum_eqFunction_12(data, threadData);

  Pendulum_eqFunction_13(data, threadData);

  Pendulum_eqFunction_14(data, threadData);

  Pendulum_eqFunction_15(data, threadData);
}

int Pendulum_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  data->simulationInfo->callStatistics.functionODE++;
  
  Pendulum_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

  
  TRACE_POP
  return 0;
}

#ifdef FMU_EXPERIMENTAL
#endif
/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "Pendulum_12jac.h"
#include "Pendulum_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks Pendulum_callback = {
   (int (*)(DATA *, threadData_t *, void *)) Pendulum_performSimulation,
   (int (*)(DATA *, threadData_t *, void *)) Pendulum_performQSSSimulation,
   Pendulum_updateContinuousSystem,
   Pendulum_callExternalObjectConstructors,
   Pendulum_callExternalObjectDestructors,
   NULL,
   NULL,
   NULL,
   #if !defined(OMC_NO_STATESELECTION)
   Pendulum_initializeStateSets,
   #else
   NULL,
   #endif
   Pendulum_initializeDAEmodeData,
   Pendulum_functionODE,
   Pendulum_functionAlgebraics,
   Pendulum_functionDAE,
   Pendulum_functionLocalKnownVars,
   Pendulum_input_function,
   Pendulum_input_function_init,
   Pendulum_input_function_updateStartValues,
   Pendulum_output_function,
   Pendulum_function_storeDelayed,
   Pendulum_updateBoundVariableAttributes,
   0 /* useHomotopy */,
   Pendulum_functionInitialEquations,
   Pendulum_functionInitialEquations_lambda0,
   Pendulum_functionRemovedInitialEquations,
   Pendulum_updateBoundParameters,
   Pendulum_checkForAsserts,
   Pendulum_function_ZeroCrossingsEquations,
   Pendulum_function_ZeroCrossings,
   Pendulum_function_updateRelations,
   Pendulum_checkForDiscreteChanges,
   Pendulum_zeroCrossingDescription,
   Pendulum_relationDescription,
   Pendulum_function_initSample,
   Pendulum_INDEX_JAC_A,
   Pendulum_INDEX_JAC_B,
   Pendulum_INDEX_JAC_C,
   Pendulum_INDEX_JAC_D,
   Pendulum_initialAnalyticJacobianA,
   Pendulum_initialAnalyticJacobianB,
   Pendulum_initialAnalyticJacobianC,
   Pendulum_initialAnalyticJacobianD,
   Pendulum_functionJacA_column,
   Pendulum_functionJacB_column,
   Pendulum_functionJacC_column,
   Pendulum_functionJacD_column,
   Pendulum_linear_model_frame,
   Pendulum_linear_model_datarecovery_frame,
   Pendulum_mayer,
   Pendulum_lagrange,
   Pendulum_pickUpBoundsForInputsInOptimization,
   Pendulum_setInputData,
   Pendulum_getTimeGrid,
   Pendulum_symEulerUpdate,
   Pendulum_function_initSynchronous,
   Pendulum_function_updateSynchronous,
   Pendulum_function_equationsSynchronous,
   NULL
   #ifdef FMU_EXPERIMENTAL
   ,Pendulum_functionODE_Partial
   ,Pendulum_functionFMIJacobian
   #endif
   ,Pendulum_inputNames


};

void Pendulum_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  data->callback = &Pendulum_callback;
  data->modelData->modelName = "Pendulum";
  data->modelData->modelFilePrefix = "Pendulum";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "/home/marium/Downloads";
  data->modelData->modelGUID = "{b8481326-0cb5-44fd-a2b0-d1a95ded0d20}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "Pendulum_init.c"
    ;
  static const char contents_info[] =
    #include "Pendulum_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "Pendulum_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "Pendulum_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  
  data->modelData->nStates = 2;
  data->modelData->nVariablesReal = 9;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 3;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 0;
  
  data->modelData->nAliasReal = 0;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 0;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 0;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.fileName = "Pendulum_info.json";
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 16;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 4;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nClocks = 0;
  data->modelData->nSubClocks = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
}

#ifdef __cplusplus
}
#endif

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
int main(int argc, char**argv)
{
  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    Pendulum_setupDataStruc(&data, threadData);
    res = _main_SimulationRuntime(argc, argv, &data, threadData);
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  EXIT(res);
  return res;
}

