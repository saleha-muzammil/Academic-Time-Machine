/* Linear Systems */
#include "Pendulum_model.h"
#include "Pendulum_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* initial linear systems */
/* initial_lambda0 linear systems */
/* parameter linear systems */
/* model linear systems */
/* jacobians linear systems */


#if defined(__cplusplus)
}
#endif

