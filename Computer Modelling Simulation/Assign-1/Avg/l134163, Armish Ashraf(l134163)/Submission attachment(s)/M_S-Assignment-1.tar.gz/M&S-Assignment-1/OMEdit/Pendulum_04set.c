/* Initial State Set */
#include "Pendulum_model.h"
#include "Pendulum_11mix.h"
#include "Pendulum_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void Pendulum_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

