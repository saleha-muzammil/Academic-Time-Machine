/* Initialization */
#include "Pendulum_model.h"
#include "Pendulum_11mix.h"
#include "Pendulum_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void Pendulum_functionInitialEquations_0(DATA *data, threadData_t *threadData);


/*
 equation index: 1
 type: SIMPLE_ASSIGN
 theeta = $_start(theeta)
 */
void Pendulum_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  data->localData[0]->realVars[1] /* theeta STATE(1,temp) */ = data->modelData->realVarsData[1].attribute /* theeta */.start;
  TRACE_POP
}

/*
 equation index: 2
 type: SIMPLE_ASSIGN
 J = 0.3333333333333333 * M * L ^ 2.0
 */
void Pendulum_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  modelica_real tmp0;
  tmp0 = data->simulationInfo->realParameter[0] /* L PARAM */;
  data->localData[0]->realVars[4] /* J variable */ = (0.3333333333333333) * ((data->simulationInfo->realParameter[1] /* M PARAM */) * ((tmp0 * tmp0)));
  TRACE_POP
}

/*
 equation index: 3
 type: SIMPLE_ASSIGN
 x = L * sin(theeta)
 */
void Pendulum_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  data->localData[0]->realVars[7] /* x variable */ = (data->simulationInfo->realParameter[0] /* L PARAM */) * (sin(data->localData[0]->realVars[1] /* theeta STATE(1,temp) */));
  TRACE_POP
}

/*
 equation index: 4
 type: SIMPLE_ASSIGN
 Torque = 0.5 * M * g * x
 */
void Pendulum_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  data->localData[0]->realVars[5] /* Torque variable */ = (0.5) * ((data->simulationInfo->realParameter[1] /* M PARAM */) * ((data->simulationInfo->realParameter[2] /* g PARAM */) * (data->localData[0]->realVars[7] /* x variable */)));
  TRACE_POP
}

/*
 equation index: 5
 type: SIMPLE_ASSIGN
 temp1 = DIVISION(-Torque, J)
 */
void Pendulum_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  data->localData[0]->realVars[6] /* temp1 variable */ = DIVISION_SIM((-data->localData[0]->realVars[5] /* Torque variable */),data->localData[0]->realVars[4] /* J variable */,"J",equationIndexes);
  TRACE_POP
}

/*
 equation index: 6
 type: SIMPLE_ASSIGN
 der(temp) = temp1
 */
void Pendulum_eqFunction_6(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,6};
  data->localData[0]->realVars[2] /* der(temp) STATE_DER */ = data->localData[0]->realVars[6] /* temp1 variable */;
  TRACE_POP
}

/*
 equation index: 7
 type: SIMPLE_ASSIGN
 y = L * cos(theeta)
 */
void Pendulum_eqFunction_7(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,7};
  data->localData[0]->realVars[8] /* y variable */ = (data->simulationInfo->realParameter[0] /* L PARAM */) * (cos(data->localData[0]->realVars[1] /* theeta STATE(1,temp) */));
  TRACE_POP
}

/*
 equation index: 8
 type: SIMPLE_ASSIGN
 temp = $_start(temp)
 */
void Pendulum_eqFunction_8(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,8};
  data->localData[0]->realVars[0] /* temp STATE(1,temp1) */ = data->modelData->realVarsData[0].attribute /* temp */.start;
  TRACE_POP
}

/*
 equation index: 9
 type: SIMPLE_ASSIGN
 der(theeta) = temp
 */
void Pendulum_eqFunction_9(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,9};
  data->localData[0]->realVars[3] /* der(theeta) STATE_DER */ = data->localData[0]->realVars[0] /* temp STATE(1,temp1) */;
  TRACE_POP
}
void Pendulum_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  Pendulum_eqFunction_1(data, threadData);
  Pendulum_eqFunction_2(data, threadData);
  Pendulum_eqFunction_3(data, threadData);
  Pendulum_eqFunction_4(data, threadData);
  Pendulum_eqFunction_5(data, threadData);
  Pendulum_eqFunction_6(data, threadData);
  Pendulum_eqFunction_7(data, threadData);
  Pendulum_eqFunction_8(data, threadData);
  Pendulum_eqFunction_9(data, threadData);
  TRACE_POP
}


int Pendulum_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  Pendulum_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Pendulum_functionInitialEquations_lambda0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}
int Pendulum_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

