/* Delay */
#include "Pendulum_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

int Pendulum_function_storeDelayed(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

