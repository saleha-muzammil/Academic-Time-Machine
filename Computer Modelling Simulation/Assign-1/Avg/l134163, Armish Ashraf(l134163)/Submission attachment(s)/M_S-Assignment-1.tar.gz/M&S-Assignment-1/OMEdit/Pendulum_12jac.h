/* Jacobians */
static const REAL_ATTRIBUTE dummyREAL_ATTRIBUTE = omc_dummyRealAttribute;
/* Jacobian Variables */
#if defined(__cplusplus)
extern "C" {
#endif
  #define Pendulum_INDEX_JAC_D 3
  int Pendulum_functionJacD_column(void* data, threadData_t *threadData);
  int Pendulum_initialAnalyticJacobianD(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* D */

#if defined(__cplusplus)
extern "C" {
#endif
  #define Pendulum_INDEX_JAC_C 2
  int Pendulum_functionJacC_column(void* data, threadData_t *threadData);
  int Pendulum_initialAnalyticJacobianC(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* C */

#if defined(__cplusplus)
extern "C" {
#endif
  #define Pendulum_INDEX_JAC_B 1
  int Pendulum_functionJacB_column(void* data, threadData_t *threadData);
  int Pendulum_initialAnalyticJacobianB(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* B */

#if defined(__cplusplus)
extern "C" {
#endif
  #define Pendulum_INDEX_JAC_A 0
  int Pendulum_functionJacA_column(void* data, threadData_t *threadData);
  int Pendulum_initialAnalyticJacobianA(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* A */
#define $PtempSeedA data->simulationInfo->analyticJacobians[0].seedVars[0]
#define $PtheetaSeedA data->simulationInfo->analyticJacobians[0].seedVars[1]


