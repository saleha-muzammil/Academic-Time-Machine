/* Linearization */
#include "Pendulum_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

const char *Pendulum_linear_model_frame()
{
  return "model linear_Pendulum\n  parameter Integer n = 2; // states\n  parameter Integer k = 0; // top-level inputs\n  parameter Integer l = 0; // top-level outputs\n"
  "  parameter Real x0[2] = {%s};\n"
  "  parameter Real u0[0] = {%s};\n"
  "  parameter Real A[2,2] = [%s];\n"
  "  parameter Real B[2,0] = zeros(2,0);%s\n"
  "  parameter Real C[0,2] = zeros(0,2);%s\n"
  "  parameter Real D[0,0] = zeros(0,0);%s\n"
  "  Real x[2](start=x0);\n"
  "  input Real u[0];\n"
  "  output Real y[0];\n"
  "\n  Real 'x_temp' = x[1];\nReal 'x_theeta' = x[2];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linear_Pendulum;\n";
}
const char *Pendulum_linear_model_datarecovery_frame()
{
  return "model linear_Pendulum\n  parameter Integer n = 2; // states\n  parameter Integer k = 0; // top-level inputs\n  parameter Integer l = 0; // top-level outputs\n  parameter Integer nz = 5; // data recovery variables\n"
  "  parameter Real x0[2] = {%s};\n"
  "  parameter Real u0[0] = {%s};\n"
  "  parameter Real z0[5] = {%s};\n"
  "  parameter Real A[2,2] = [%s];\n"
  "  parameter Real B[2,0] = zeros(2,0);%s\n"
  "  parameter Real C[0,2] = zeros(0,2);%s\n"
  "  parameter Real D[0,0] = zeros(0,0);%s\n"
  "  parameter Real Cz[5,2] = [%s];\n"
  "  parameter Real Dz[5,0] = zeros(5,0);%s\n"
  "  Real x[2](start=x0);\n"
  "  input Real u[0];\n"
  "  output Real y[0];\n"
  "  output Real z[5];\n"
  "\nReal 'x_temp' = x[1];\nReal 'x_theeta' = x[2];\nReal 'z_J' = z[1];\nReal 'z_Torque' = z[2];\nReal 'z_temp1' = z[3];\nReal 'z_x' = z[4];\nReal 'z_y' = z[5];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linear_Pendulum;\n";
}
#if defined(__cplusplus)
}
#endif

