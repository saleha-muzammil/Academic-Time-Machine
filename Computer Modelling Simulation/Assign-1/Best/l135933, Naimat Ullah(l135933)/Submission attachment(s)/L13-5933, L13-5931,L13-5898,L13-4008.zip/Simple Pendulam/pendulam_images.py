import csv
import sys
import time
from PIL import Image, ImageDraw

size = (800,800)
mid = 128
mode = 'RGB'
x = 0
y = 0
X = 0
Y = 0
radius = 5
radiusSmall = 2
pointArray = [(400, 200)]
preX = 400
preY = 200
time = 0
imgNum  = 0
im = Image.new(mode, size, color=0)
draw = ImageDraw.Draw(im)
draw.point((400, 200), 'white')
f = open(sys.argv[1], 'rt')
try:
  reader = csv.reader(f)
  for row in reader:
    toggle = 0
    for entry in row:
      toggle += 1
      if toggle == 1:
        time = entry
      if toggle == 2:
        x = entry
      if toggle == 3:
        y = entry
        toggle = 0

        X = 400 + float(x) * 500
        Y = 200 + float(y) * 500
        draw.line( ( 400, 200, preX, preY), 'black');
        draw.line( ( 400, 200, X,Y), 'white');
        draw.ellipse((preX-radius, preY-radius, preX+radius, preY+radius), 'black')
        for i in pointArray:
          draw.point( i, 'white')

        draw.ellipse((X-radius, Y-radius, X+radius, Y+radius), 'white')
        imgNum += 1
        im.save("tem" + str(imgNum) + ".jpg", "JPEG")
        pointArray.append([(X, Y)])
        if len(pointArray) > 5:
          pointArray.pop(0)

        preX = X
        preY = Y



finally:
    f.close()
