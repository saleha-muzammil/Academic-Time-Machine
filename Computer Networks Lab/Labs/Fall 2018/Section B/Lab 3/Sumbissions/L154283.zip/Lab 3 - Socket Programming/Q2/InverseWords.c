#include <stdlib.h>
#include <string.h>

void inverseWord(char *word)
{
  char *left = word;
  char *right = word + (strlen(word) - 1);

  while (left < right)
  {
    char temp = *left;
    *left = *right;
    *right = temp;

    left++;
    right--;
  }
}

void inverseWordsVowels(char *str, char containingVowels)
{
  char *temp = (char *)malloc(strlen(str) + 1);
  strcpy(temp, str);
  memset(str, 0, sizeof(str));

  char *delimiter = " ";
  char *word = strtok(temp, delimiter);

  while (word != NULL)
  {
    char hasVowel = 0;
    char *vowels = "aeiouAEIOU";
    char *nextVowel = strpbrk(word, vowels);

    while (nextVowel != NULL)
    {
      hasVowel = 1;
      nextVowel = strpbrk(nextVowel + 1, vowels);
    }

    if (hasVowel == containingVowels)
    {
      inverseWord(word);
    }

    strcat(str, word);
    strcat(str, delimiter);

    word = strtok(NULL, delimiter);
  }
}