/*
        TCP_Client. This Program will implement the Client Side for TCP_Socket Programming.
        It will get some data from user and will send to the server and as a reply from the
        server, it will get its data back.
*/

#include <stdio.h>
#include <string.h>
#include <sys/socket.h> //socket
#include <arpa/inet.h> //inet_addr
void reverse_words(char *s) {
  char b[100], *t, *z;
  int c = 0;
 
  t = s;
 
  while(*t) {                           //processing complete string
    while(*t != ' ' && *t != '\0') {    //extracting word from string
      if(*t == 'a' || *t == 'e' || *t == 'i' || *t == 'o' || *t == 'u')
      {
			
      b[c] = *t;
      t++;
      c++;
      }
    }
    b[c] = '\0';
    c = 0;
 
    reverse_string(b);        // reverse the extracted word
 
    z = b;
 
    while (*z) {    //copying the reversed word into original string
      *s = *z;
      z++;
      s++;
    }
 
    while (*s == ' ') {                 // skipping space(s)
      s++;
    }
    /*
     * You may use if statement in place of while loop if
     * you are assuming only one space between words. If condition is
     * used because null terminator can also occur after a word, in
     * that case we don't want to increment pointer.
     * if (*s == ' ') {
     *   s++;
     * }
     */
    t = s;                              // pointing to next word
  }
}
 
/*
 * Function to reverse a word.
 */
 
void reverse_string(char *t) {
  int l, c;
  char *e, s;
 
  l = strlen(t);
  e = t + l - 1;
 
  for (c = 0; c < l/2; c++) {
    s  = *t;
    *t = *e;
    *e = s;
    t++;
    e--;
  }
}
int main(void)
{
        int socket_desc;
        struct sockaddr_in server_addr;
        char server_message[2000], client_message[2000];
        
        //Cleaning the Buffers
        
        memset(server_message,'\0',sizeof(server_message));
        memset(client_message,'\0',sizeof(client_message));
        
        //Creating Socket
        
        socket_desc = socket(AF_INET, SOCK_STREAM, 0);
        
        if(socket_desc < 0)
        {
                printf("Could Not Create Socket. Error!!!!!\n");
                return -1;
        }	
        
        printf("Socket Created\n");
        
        //Specifying the IP and Port of the server to connect
        
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(2000);
        server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
        
        //Now connecting to the server accept() using connect() from client side
        
        if(connect(socket_desc, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0)
        {
                printf("Connection Failed. Error!!!!!");
                return -1;
        }
        
        printf("Connected\n");
        
        //Get Input from the User
        
        printf("Enter message: ");
        gets(client_message);
        
        //Send the message to Server
        
        if(send(socket_desc, client_message, strlen(client_message),0) >= 0)
        {/*
        	int i=0;int j=0;int recent=0;int lasts=0;int nexts=0;
        	while(i< strlen(client_message))
		{
			if(client_message[i] == 'a' || client_message[i] == 'e' || client_message[i] == 'i' || client_message[i] == 'o' || client_message[i] == 'u')
			{
				recent=i;
				j=i; 
				while( client_message[j] != ' ')
				{
					j++;
					nexts=j;
				}
				nexts=nexts+1;
				j=i;
				while( client_message[j] != ' ')
				{
					j--;
					lasts=j;
				}		
       				lasts=lasts-1;
       				int size=nexts-lasts;
       				char temp[size]; int k=0; int n=lasts;
       				while( k<(size))
       				{
       				
	       				temp[k]=client_message[n];
       					k++;n++;
       				}
				k=0;  n=lasts;
       				while( k<(size))
       				{
       				
	       				client_message[n]=temp[k];
       					k++;n++;
       				}printf("%s\n", temp);
       						
			}
		
		
			i++;
		}*/
		

  
       		reverse_words(client_message) ;
		
		printf("%s\n", client_message);

        }
        else
        {
                printf("Send Failed. Error!!!!\n");
                return -1;
        
        }

        
        //Receive the message back from the server
        
        if(recv(socket_desc, server_message, sizeof(server_message),0) < 0)
        {
                printf("Receive Failed. Error!!!!!\n");
                return -1;
        }
        

        
        memset(server_message,'\0',sizeof(server_message));
        memset(client_message,'\0',sizeof(client_message));
        
        //Closing the Socket
        
        close(socket_desc);
        
        return 0;
}

