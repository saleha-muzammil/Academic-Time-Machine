MNIST data set for digits 3, 4, 5, 9 only.
Dimensions of images is 28x28
Each row contains one digit with 784 pixel values + 1 label at the end.
Use train set for training the model and validation set for model selection.
Report both training and validation accuracies and errors in the report.
