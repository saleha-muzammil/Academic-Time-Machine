The links of these two tutorials are as follows:

https://www.analyticsvidhya.com/blog/2016/01/complete-tutorial-learn-data-science-python-scratch-2/



https://www.analyticsvidhya.com/blog/2014/09/data-munging-python-using-pandas-baby-steps-python/


