#pragma once
#include <iostream>
#include <vector>
#ifndef H_Route
#define H_Route
#endif

using namespace std;

class Airport
{
	int key;								//key number of Airport in list of Airports
	char code[4];							//4-character unique code of Airport
	string location;						//city where Airport resides in
	string country;							//country where Airport resides
	string name;							//official name of the Airport
	vector<Airport*> listOfConnections;		//vector containing pointers to Airports that are it's Neighbours
	int numberOfConnections;				//number of Neighbours of Airport
	double tentativeDistance;				//shortest distance of Airport calculated so far from the initial Airport
	long double latitude;					//latitude coordinates of the Airport(to 4 decimal places)
	long double longitude;					//latitude coordinates of the Airport(to 4 decimal places)
	vector<bool> adjacencyList;				//vector containing adjacency list values
	bool visited;							//if Airport has been visited, then visited = 1, else visited = 0
public:
	Airport()
	{

	}

	Airport(int k, char c[3], string l, string co, string n, int num, long double lat, long double lon)
	{
		this->key = k;
		code[0] = toupper(c[0]); code[1] = toupper(c[1]); code[2] = toupper(c[2]); code[3] = toupper(c[3]);
		this->country = co;
		this->location = l;
		this->name = n;
		this->numberOfConnections = num;
		this->latitude = lat;
		this->longitude = lon;
		tentativeDistance = INFINITY;
		visited = false;
	}

	Airport(const Airport &obj)						//copy constructor
	{
		key = obj.key;
		code[0] = obj.code[0]; code[1] = obj.code[1]; code[2] = obj.code[2];
		location = obj.location;
		country = obj.country;
		name = obj.name;
		for (int i = 0; i < numberOfConnections; i++)
		{
			listOfConnections[i] = obj.listOfConnections[i];
		}
		numberOfConnections = obj.numberOfConnections;
		tentativeDistance = obj.tentativeDistance;
		latitude = obj.latitude;
		longitude = obj.longitude;

		for (int i = 0; i < numberOfConnections; i++)
		{
			adjacencyList[i] = obj.adjacencyList[i];
		}
	}

	const Airport& operator=(const Airport& obj)		//to copy airport in list of connections
	{
		key = obj.key;
		code[0] = obj.code[0]; code[1] = obj.code[1]; code[2] = obj.code[2];
		location = obj.location;
		country = obj.country;
		name = obj.name;
		for (int i = 0; i < numberOfConnections; i++)
		{
			listOfConnections[i] = obj.listOfConnections[i];
		}
		numberOfConnections = obj.numberOfConnections;
		tentativeDistance = obj.tentativeDistance;
		latitude = obj.latitude;
		longitude = obj.longitude;
		for (int i = 0; i < numberOfConnections; i++)
		{
			adjacencyList[i] = obj.adjacencyList[i];
		}
	}

	void add_neighbour_to_vector_of_connections(Airport *p)
	{
		listOfConnections.push_back(p);
	}

	bool get_adjacency_value(int i)
	{
		return adjacencyList[i];
	}

	vector<bool> get_adjacencyList_vector()
	{
		return adjacencyList;
	}

	bool get_visited()
	{
		return visited;
	}

	string get_location()
	{
		return location;
	}

	int get_key()
	{
		return key;
	}

	int get_numberOfConnections()
	{
		return numberOfConnections;
	}

	double get_tentative_Distance()
	{
		return tentativeDistance;
	}

	long double get_latitude()
	{
		return latitude;
	}

	long double get_longitude()
	{
		return longitude;
	}

	void set_vector_of_connections(vector<bool> temp_adjacencyList)
	{
		adjacencyList = temp_adjacencyList;
	}

	void set_visited(bool v)
	{
		visited = v;
	}

	void set_name(string x)
	{
		name = x;
	}

	void set_tentative_distance(double d)
	{
		tentativeDistance = d;
	}

	void set_numberOfConnections(int n)
	{
		numberOfConnections = n;
	}

	void set_key(int k)
	{
		key = k;
	}
};