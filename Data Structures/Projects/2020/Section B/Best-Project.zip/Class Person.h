#pragma once
#include <iostream>
using namespace std;

class Person
{
	string name;					//name of Person
	string current_position;		//name of city where Person is located currently
	int age;						//current age of Person
	string CNIC;					//CNIC number of Person of the country where he begins his Journey from
public:
	Person()
	{
		name = "\0";
		current_position = "\0";
		age = 0;
		CNIC = "\0";
	}

	string get_name()
	{
		return name;
	}

	int get_age()
	{
		return age;
	}

	string get_CNIC()
	{
		return CNIC;
	}

	string get_current_position()
	{
		return current_position;
	}

	void set_current_position(string cp)
	{
		current_position = cp;
	}

	void set_name(string x)
	{
		name = x;
	}

	void set_age(int a)
	{
		age = a;
	}

	void set_CNIC(string cnic)
	{
		CNIC = cnic;
	}
};
