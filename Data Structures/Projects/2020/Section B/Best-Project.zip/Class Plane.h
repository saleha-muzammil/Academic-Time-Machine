#pragma once
#include <iostream>
using namespace std;

class Plane
{
	string name;				//name of the flag carrier company
	string model;				//model of the Plane
	char call_sign[5];			//5-character unique call sign of the flight
	double flightRate;			//charges of the flight
	int passengers_capacity;	//passenger capacity of the plane
public:
	Plane()
	{
		name = '\0';
		model = '\0';
		flightRate = 0.00;
		call_sign[0] = '\0'; call_sign[1] = '\0'; call_sign[2] = '\0'; call_sign[3] = '\0'; call_sign[4] = '\0';
		passengers_capacity = 0;
	}

	Plane(string n, string m, char cs[4], double fR, int pC)
	{
		this->name = n;
		this->model = m;
		call_sign[0] = cs[0]; call_sign[1] = cs[1]; call_sign[2] = cs[2]; call_sign[3] = cs[3]; call_sign[4] = cs[4];
		this->flightRate = fR;
		this->passengers_capacity = pC;
	}

	const Plane& operator=(const Plane& obj)
	{
		name = obj.name;
		model = obj.model;
		call_sign[0] = obj.call_sign[0]; call_sign[1] = obj.call_sign[1]; call_sign[2] = obj.call_sign[2]; call_sign[3] = obj.call_sign[3]; call_sign[4] = obj.call_sign[4];
		flightRate = obj.flightRate;
		passengers_capacity = obj.passengers_capacity;
	}

	char get_call_sign(int i)
	{
		return call_sign[i];
	}

	double get_flightRate()
	{
		return flightRate;
	}

	void set_flightName(string f)
	{
		name = f;
	}
};