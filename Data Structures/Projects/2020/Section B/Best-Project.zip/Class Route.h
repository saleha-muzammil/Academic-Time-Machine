#pragma once
#include <iostream>
#include "Class Airport.h"
using namespace std;

class Route
{
	Airport *point1;		//pointer to Airport at one end of the Route
	Airport *point2;		//pointer to Airport at second end of the Route
	double distance;			//estimated angular length of the Route
public:
	Route()
	{
		point1 = nullptr;
		point2 = nullptr;
		distance = 0;
	}

	double get_distance()
	{
		return distance;
	}

	void get_keysOfConnectedAirports(int &k1, int &k2)
	{
		k1 = point1->get_key();		//get key of airport on end 1
		k2 = point2->get_key();		//get key of airport on end 2
	}

	void set_point1(Airport *p1)
	{
		point1 = p1;
	}

	void set_point2(Airport *p2)
	{
		point2 = p2;
	}

	void set_distance(double d)
	{
		distance = d;
	}
};