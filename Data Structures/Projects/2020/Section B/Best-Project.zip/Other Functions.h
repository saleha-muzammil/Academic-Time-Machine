//go to 'main program.cpp' for the program code
#pragma once

#include <iostream>				//for cin, cout
#include <Windows.h>			//for type 'HANDLE', GetStdHandle(), PlaySound()
#include <iomanip>				//for setw(), exit()
#include <fstream>				//for fin, fout
#include <cstring>				//for string functions
#include <string>				//for type 'string'
#include <cmath>				//for sin(), cos(), atan2(), pow(), sqrt()
#include <vector>				//for vector container  
#include <deque>				//for double ended queue container
#include <stack>				//for stack container
#include "Class Airport.h"		//for class Airport
#include "Class Route.h"		//for class Route
#include "Class Plane.h"		//for class Plane
#include "Class Person.h"		//for class Person
#include <conio.h>				//for _getch()
#include <stdio.h>
#include <locale>
#include <stdlib.h>				//for rand(), srand()
#include <time.h>				//for time()

using namespace std;

void colour_code(HANDLE &h, int colour)
{
	switch (colour)
	{
	case 1:
		SetConsoleTextAttribute(h, FOREGROUND_RED);								//red
		break;
	case 2:
		SetConsoleTextAttribute(h, FOREGROUND_BLUE);							//dark blue
		break;
	case 3:
		SetConsoleTextAttribute(h, FOREGROUND_GREEN);							//dark green
		break;
	case 4:
		SetConsoleTextAttribute(h, FOREGROUND_BLUE + FOREGROUND_RED);			//purple
		break;
	case 5:
		SetConsoleTextAttribute(h, FOREGROUND_RED + FOREGROUND_GREEN);			//yellow
		break;
	case 6:
		SetConsoleTextAttribute(h, FOREGROUND_RED + FOREGROUND_INTENSITY);		//pink
		break;
	case 7:
		SetConsoleTextAttribute(h, FOREGROUND_BLUE + FOREGROUND_GREEN);			//blue
		break;
	case 8:
		SetConsoleTextAttribute(h, FOREGROUND_BLUE + FOREGROUND_INTENSITY);		//navy blue
		break;
	case 9:
		SetConsoleTextAttribute(h, FOREGROUND_GREEN + FOREGROUND_INTENSITY);	//green
		break;
	default:
		SetConsoleTextAttribute(h, FOREGROUND_INTENSITY);						//grey
	}
}

void endl(int previous_colour)
{
	cout << endl << "   ";
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	colour_code(h, previous_colour);
}

void file_opening_error()
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	endl(1);
	cout << "Error F03: File could not be opened." << endl;
	exit(EXIT_FAILURE);
}

unsigned int get_random_number(int max_value)
{
	srand(time(0));
	return rand() % max_value;
}

void destination_call(int destination_number)
{
	switch (destination_number)
	{
	case 0:
		PlaySound("Buzzer Sound", NULL, SND_SYNC);
		break;
	case 1:
		PlaySound("Welcome to Allama Iqbal International Airport, Lahore", NULL, SND_SYNC);
		break;
	case 2:
		PlaySound("Welcome to Kuala Lumpur International Airport, Kuala Lampur", NULL, SND_SYNC);
		break;
	case 3:
		PlaySound("Welcome to Indira Gandhi International Airport, New Delhi", NULL, SND_SYNC);
		break;
	case 4:
		PlaySound("Welcome to Haneda Airport, Tokyo", NULL, SND_SYNC);
		break;
	case 5:
		PlaySound("Welcome to Canberra Airport, Canberra", NULL, SND_SYNC);
		break;
	case 6:
		PlaySound("Welcome to Paris-Charles De Gaulle, Paris", NULL, SND_SYNC);
		break;
	case 7:
		PlaySound("Welcome to Istanbul Airport, Istanbul", NULL, SND_SYNC);
		break;
	case 8:
		PlaySound("Welcome to Toronto Pearson International Airport, Toronto", NULL, SND_SYNC);
		break;
	case 9:
		PlaySound("Welcome to Mexico City International Airport, Mexico City", NULL, SND_SYNC);
		break;
	case 10:
		PlaySound("Welcome to Sheremetyevo - Alexander S. Pushkin International Airport, Moscow", NULL, SND_SYNC);
		break;
	case 11:
		PlaySound("Welcome to Helsinki Airport, Helsinki", NULL, SND_SYNC);
		break;
	case 12:
		PlaySound("Welcome to International Airport of Brasilia, Brasilia", NULL, SND_SYNC);
		break;
	case 13:
		PlaySound("Welcome to Ronald Reagan International Airport, Washington DC", NULL, SND_SYNC);
		break;
	case 14:
		PlaySound("Welcome to King Khalid International Airport, Riyadh", NULL, SND_SYNC);
		break;
	case 15:
		PlaySound("Welcome to Wellington International Airport, New Zealand", NULL, SND_SYNC);
		break;
	case 16:
		PlaySound("Welcome to Ezeiza International Airport, Buenos Aires", NULL, SND_SYNC);
		break;
	case 17:
		PlaySound("Welcome to Soekarno-Hatta International Airport, Jakarta", NULL, SND_SYNC);
		break;
	}
}
