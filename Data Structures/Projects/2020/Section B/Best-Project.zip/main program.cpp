//A FLIGHT OPERATION SERVICE

//PLEASE FOLLOW THESE INSTRUCTIONS TO CORRECTLY RUN THE PROGRAM:
//-Open Properties of this project solution(click right on the purple box in the Solution Explorer on the left/right
//-Expand 'Linker' in 'Configuration Properties'
//-Left Click on 'Input'
//-In the first option in the opening bar, 'Additional Dependencies', left click on the option available and press on '<Edit>'
//-Type in "Winmm.lib", without speech marks, to enable voice frequencies for use of PlaySound() function

#include "Other Functions.h"	//for functions colour_code(), get_random_number(), destination_call(), endl(), file_opening_error(), header files

using namespace std;

long double toRadians(const long double degree)
{
	const double pi = 3.14159265358979323846;
	long double one_deg = (pi) / 180;
	return (one_deg*degree);
}

double Haversine_Formula(long double lat1, long double long1, long double lat2, long double long2)
{
	//Convert the latitudes and longitudes from degree to radians
	lat1 = toRadians(lat1);
	lat2 = toRadians(lat2);
	long1 = toRadians(long1);
	long2 = toRadians(long2);

	//Haversine Formula
	long double dlong = long2 - long1;		//difference between longitude coordinates
	long double dlat = lat2 - lat1;			//difference between latitude coordinates

	long double circular_distance = pow(sin(dlat / 2), 2) + cos(lat1)*cos(lat2)*pow(sin(dlong / 2), 2);
	circular_distance = 2 * asin(sqrt(circular_distance));

	long double Earth_Radius = 6371;		//radius of Earth = 6371 kilometres
	circular_distance *= Earth_Radius;

	return (double)circular_distance;
}

void Show_Graph()
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	ifstream fin("Graph Details.txt");
	if (!fin)
		file_opening_error();

	string printer;
	cout << endl; endl(5);
	while (getline(fin, printer))		//read and print complete file
	{
		cout << printer << endl;
	}
	fin.close();
	cout << endl; endl(5);
}

void leave()		//function to exit menu loop and exit program while displaying a message
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	endl(5);

	cout << "Thank You For Visiting. Have A Good Day.";
	PlaySound("Thank you for visiting. Have a good day", NULL, SND_SYNC);
	//first paramter: name of file, second paramter: NULL, third parameter: asynchronous/synchronous sound
}

void traverse_Airports(Airport **list_Of_Airports, Route *list_Of_Routes, int start_point, int number_Of_Airports, int numberOfRoutes)
{
	int key1 = 0, key2 = 0, linkNumber = -1;
	int this_key = -1;
	int traverse_Airports = -1;						//keeps position of Airport in the vector of Airport connections
	double updated_Distance = 0;
	deque<Airport*> Neighbouring_Airport_Deque;		//deque to store pointers of neighbouring Airports

	Airport* temp_Airport;							//to store pointer to airport popped from stack, to e observed
	Airport* next_Airport = NULL;					//to mark airport distance of neighbour

	Neighbouring_Airport_Deque.push_back(list_Of_Airports[start_point]);		//push starting Airport onto queue

	//traversal for airports
	for (int h = 1; h <= (number_Of_Airports); h++)								//this for loop searches for each Airport
	{
		temp_Airport = Neighbouring_Airport_Deque.front();
		Neighbouring_Airport_Deque.pop_front();									//remove pointer of Airport from queue
		int number_of_Neighbours = temp_Airport->get_numberOfConnections();
		for (int i = 0; i < number_of_Neighbours; i++)							//this for loop searches for each neighbour of a certain Airport
		{
			for (int j = 0; j < numberOfRoutes; j++)							//this for loop linearly searches the array of routes
			{
				list_Of_Routes[j].get_keysOfConnectedAirports(key1, key2);		//get Airports on each ends of the Route
				int j2 = j;

				if (key1 == temp_Airport->get_key())							//if key matches with one key of the linked Airports
				{
					next_Airport = list_Of_Airports[key2 - 1];					//move to Neighbouring Airport with the other key
					this_key = key1 - 1;
					linkNumber = j;												//save the position of link
					j = numberOfRoutes;											//end for loop-j

					if (!next_Airport->get_visited())							//if unvisited
					{
						Neighbouring_Airport_Deque.push_back(next_Airport);		//push this neighbour onto queue
						next_Airport->set_visited(true);						//Airports have been set to visited
					}
					else if (next_Airport->get_visited())
						j = j2;
				}
				else if ((key2 == temp_Airport->get_key()))						//if key matches with the second key of the linked Airports
				{
					next_Airport = list_Of_Airports[key1 - 1];					//move to Neighbouring Airport with the other key
					this_key = key2 - 1;
					linkNumber = j;												//save the position of link
					j = numberOfRoutes;											//end for loop-j

					if (!next_Airport->get_visited())							//if unvisited
					{
						Neighbouring_Airport_Deque.push_back(next_Airport);		//push this neighbour onto queue
						next_Airport->set_visited(true);						//Airports have been set to visited
					}
					else if (next_Airport->get_visited())
						j = j2;
				}
			}

			double tentative_distance = next_Airport->get_tentative_Distance();
			double route_length = list_Of_Routes[linkNumber].get_distance();
			if (tentative_distance > (route_length + temp_Airport->get_tentative_Distance()))
			{
				updated_Distance = (route_length)+(list_Of_Airports[this_key]->get_tentative_Distance());
				next_Airport->set_tentative_distance(updated_Distance);						//set tentative distance of neighbouring airport
			}
		}
	}
	//at this point
	//all Airports have been marked visited
	//all tentative distances of Airports have been updated
	//we have the shortest distances of each Airport from the starting Airport
}

double shortestDistanceCalculate(int start_point_key, int end_point_key, Route *list_Of_Routes, Plane **list_Of_Planes, Airport **list_Of_Airports, int numberOfRoutes)		//function calculates shortest distance
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	double distance = 0;

	ifstream fin("Creating Circuit.txt");
	if (!fin)
		file_opening_error();

	int numberOfAirports = 0;
	fin >> numberOfAirports;		//extract total number of airports
	fin.close();					//close file

	int start_position = 0;
	for (int i = 0; i < numberOfAirports; i++)
	{
		if ((list_Of_Airports[i]->get_key()) == start_point_key)
		{
			start_position = i;
			i = numberOfAirports;
		}
	}
	//now we know the starting position

	int end_position = 0;
	for (int i = 0; i < numberOfAirports; i++)
	{
		if ((list_Of_Airports[i]->get_key()) == end_point_key)
		{
			end_position = i;
			i = numberOfAirports;
		}
	}
	//now we know the target position

	list_Of_Airports[start_position]->set_tentative_distance(0);					//tentative distance of starting position is initially set to zero
	list_Of_Airports[start_position]->set_visited(true);							//initial starting position is set to have been visited
	traverse_Airports(list_Of_Airports, list_Of_Routes, start_position, numberOfAirports, numberOfRoutes);
	distance = list_Of_Airports[end_position]->get_tentative_Distance();

	return distance;
}

string routeCompleter(int start_point_key, int end_point_key, Route *list_Of_Routes, Plane **list_Of_Planes, Airport **list_Of_Airports, Person &Customer1, int numberOfAirports, int numberOfRoutes)		//function transfers person to a place in the virtual graph using the shortest distance
{
	int start_position = 0;
	for (int i = 0; i < numberOfAirports; i++)
	{
		if ((list_Of_Airports[i]->get_key()) == start_point_key)
		{
			start_position = i;
			i = numberOfAirports;
		}
	}
	Customer1.set_current_position(list_Of_Airports[start_position]->get_location());		//person is at starting position

	int end_position = 0;
	for (int i = 0; i < numberOfAirports; i++)
	{
		if ((list_Of_Airports[i]->get_key()) == end_point_key)
		{
			end_position = i;
			i = numberOfAirports;
		}
	}
	//now we know the target position

	list_Of_Airports[start_position]->set_tentative_distance(0);							//tentative distance of starting position is initially set to zero
	list_Of_Airports[start_position]->set_visited(true);									//initial starting position is set to have been visited
	traverse_Airports(list_Of_Airports, list_Of_Routes, start_position, numberOfAirports, numberOfRoutes);	//proceed to traverse each airport through respective connected routes
	Customer1.set_current_position(list_Of_Airports[end_position]->get_location());			//person is at final position
	return Customer1.get_current_position();												//return string location of final location
}

void Default_Setting_Airport(Airport **list_Of_Airports)
{
	ifstream fin("Creating Circuit.txt");
	if (!fin)
		file_opening_error();

	int number_Of_Airports = 0;
	fin >> number_Of_Airports;
	fin.close();
	for (int i = 0; i < number_Of_Airports; i++)
	{
		list_Of_Airports[i]->set_tentative_distance(INFINITY);
		list_Of_Airports[i]->set_visited(false);
	}
}

void flightDetails(int start_point_key, int end_point_key, double fRate, Route *list_Of_Routes, Plane **list_Of_Planes, Airport **list_Of_Airports, int numberOfRoutes)		//function returns the total cost of a flight
{
	double distance = shortestDistanceCalculate(start_point_key, end_point_key, list_Of_Routes, list_Of_Planes, list_Of_Airports, numberOfRoutes);		//proceed to calculate total cost of your shortest path
	double flightCost = distance * fRate;

	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	endl(3);
	cout << "Total Distance: ";
	colour_code(h, 6);
	cout << distance << " Kilometres."; endl(3);
	cout << "Flight Rate:    ";
	colour_code(h, 6);
	cout << setprecision(0) << "$" << fRate; endl(3); endl(3);
	cout << "Your flight ticket costs $" << flightCost << "."; endl(1);
	Default_Setting_Airport(list_Of_Airports);		//default settings of Airports

	cout << "_____________________________________________________________________________________________________________";
}

void get_path(Route *list_Of_Routes, Airport **list_Of_Airports, int numberOfAirports, Person &Customer1, int out_key, int numberOfRoutes)
{
	int end_position = 0;
	for (int i = 0; i < numberOfAirports; i++)
	{
		if ((list_Of_Airports[i]->get_key()) == out_key)
		{
			end_position = i;
			i = numberOfAirports;					//end for loop-i
		}
	}
	//target position is saved in end_position

	int key1 = 0, key2 = 0, number_Of_Airports_Visited = 0;
	double temp_distance = list_Of_Airports[end_position]->get_tentative_Distance();
	Airport *temp_Airport = list_Of_Airports[end_position];
	Airport* next_Airport = NULL;
	stack<string> Stack_of_Locations;				//deque to store the path taken

	Stack_of_Locations.push(temp_Airport->get_location());

	for (int i = 1; i <= numberOfRoutes; i++)				//this for loop, in worst case scenario, repeats times the number of total routes available
	{
		int num = temp_Airport->get_numberOfConnections();
		for (int j = 0; j < num; j++)		//this for loop searches each neighbouring Airport
		{
			for (int k = 0; k < numberOfRoutes; k++)
			{
				list_Of_Routes[k].get_keysOfConnectedAirports(key1, key2);		//get Airports on each ends of the Route
				int k2 = k;

				if (key1 == temp_Airport->get_key())					//if key matches with one key of the linked Airports
				{
					next_Airport = list_Of_Airports[key2 - 1];			//move to Neighbouring Airport with the other key

					if ((temp_Airport->get_tentative_Distance()) == (list_Of_Routes[k].get_distance()) + (next_Airport->get_tentative_Distance()))
					{
						j = num;					//terminate for loop-j
						temp_Airport = next_Airport;									//move to the previous Airport
						Stack_of_Locations.push(temp_Airport->get_location());			//save location
						k = numberOfRoutes;												//terminate for loop-k

						if (temp_Airport->get_tentative_Distance() == 0)				//if arrived at starting point
							i = numberOfRoutes + 1;										//terminate for loop-i
					}
				}
				else if ((key2 == temp_Airport->get_key()))				//if key matches with the second key of the linked Airports
				{
					next_Airport = list_Of_Airports[key1 - 1];			//move to Neighbouring Airport with the other key

					if ((temp_Airport->get_tentative_Distance()) == (list_Of_Routes[k].get_distance()) + (next_Airport->get_tentative_Distance()))
					{
						j = num;					//terminate for loop-j
						temp_Airport = next_Airport;									//move to the previous Airport
						Stack_of_Locations.push(temp_Airport->get_location());			//save location
						k = numberOfRoutes;												//terminate for loop-k

						if (temp_Airport->get_tentative_Distance() == 0)				//if arrived at starting point
							i = numberOfRoutes + 1;										//terminate for loop-i
					}
				}

			}
		}
		number_Of_Airports_Visited++;
	}

	ifstream fin("History.txt");
	if (!fin)
		file_opening_error();

	stack <string>stck;
	string dumplace;
	while (!fin.eof())
	{
		getline(fin, dumplace, '\n');
		if(dumplace != "")
			stck.push(dumplace);
	}
	fin.clear();
	fin.close();

	ofstream fout("History.txt", ios::out);
	if (!fout)
		file_opening_error();

	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	string place = "\0";
	cout << setw(10);
	for (int i = number_Of_Airports_Visited; i >= 0; i--)
	{
		place = Stack_of_Locations.top();
		Stack_of_Locations.pop();
		fout << place << endl;
		colour_code(h, 5);

		cout << place;			//print locations visited

		colour_code(h, 9);
		if (i != 0)
			cout << " -> ";
	}
	while (!stck.empty())
	{
		fout << stck.top() << endl;
		stck.pop();

	}
	fout.close();
}

void bookAFlight(int start_point_key, int end_point_key, char flight[4], Route *list_Of_Routes, Plane **list_Of_Planes, Airport **list_Of_Airports, Person &Customer1, int numberOfRoutes)		//function allows to transfer person from one point to another
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	string final_location = "\0";

	ifstream fin("Creating Circuit.txt");
	if (!fin)
		file_opening_error();

	int numberOfAirports = 0;
	fin >> numberOfAirports;		//extract total number of airports
	fin.close();					//close file

	final_location = routeCompleter(start_point_key, end_point_key, list_Of_Routes, list_Of_Planes, list_Of_Airports, Customer1, numberOfAirports, numberOfRoutes);		//proceed to transport person

	endl(3);
	cout << "Flight No. " << flight[0] << flight[1] << flight[2] << flight[3] << flight[4] << " has landed at" << final_location << "." << endl;
	PlaySound("airport_announcement", NULL, SND_SYNC);			//bell
	//first paramter: name of file, second paramter: NULL, third parameter: asynchronous/synchronous sound

	destination_call(end_point_key);		//audio of the place you have arrived at
	_getch(); endl(3);
	Show_Graph();

	colour_code(h, 3);
	cout << "Flight Details: " << endl;
	get_path(list_Of_Routes, list_Of_Airports, numberOfAirports, Customer1, end_point_key, numberOfRoutes);

	Default_Setting_Airport(list_Of_Airports);		//default settings of Airports
}

void show_flights()		//function to display all the flights and their rates
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

	colour_code(h, 1);
	cout << "________________________________________________________________________________________________________________________________________________" << endl;
	cout << "|Flight Number | Flight Name                              | Model                          | Call Sign       | Flight Rate    |    Capacity    |" << endl;
	cout << "________________________________________________________________________________________________________________________________________________" << endl;

	ifstream fin("Creating Planes.txt");
	if (!fin)
		file_opening_error();

	int number_Of_Flights = 0;
	fin >> number_Of_Flights;		//extract number of flights available

	for (int i = 0; i < number_Of_Flights; i++)
	{
		char temp_name[50];
		char temp_model[50];
		char temp_call_sign[20];
		double temp_rate = 0.0;
		int temp_capacity = 0;

		fin.ignore(1);
		fin.getline(temp_name, 49, ',');
		fin.getline(temp_model, 49, ',');
		fin.getline(temp_call_sign, 19, ',');
		fin.ignore(1);
		fin >> temp_rate;
		fin.ignore(2);
		fin >> temp_capacity;

		colour_code(h, 1);
		cout << "|      ";

		colour_code(h, 3);
		cout << (i + 1);

		if ((i + 1) < 10)
			cout << " ";

		colour_code(h, 1);
		cout << "      |";

		colour_code(h, 3);
		cout << "     " << (string)temp_name;

		colour_code(h, 1);
		cout << " | ";

		colour_code(h, 3);
		cout << (string)temp_model;

		colour_code(h, 1);
		cout << " | ";

		colour_code(h, 3);
		cout << (string)temp_call_sign;

		colour_code(h, 1);
		cout << "         |   ";

		colour_code(h, 3);
		cout << fixed << showpoint;
		cout << setprecision(1) << temp_rate;

		colour_code(h, 1);
		cout << "         |        ";

		colour_code(h, 3);
		cout << temp_capacity;

		colour_code(h, 1);
		cout << "     |" << endl;
		cout << "________________________________________________________________________________________________________________________________________________" << endl;
	}
	cout << setprecision(3);
	cout << endl << endl;
	fin.close();
}

void viewHistory()		//function to view last visited place on stack
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	endl(2);

	ifstream fin("History.txt");
	if (!fin)
		file_opening_error();

	string place = "\0";
	cout << setw(20) << "Flight History"; endl(2);
	cout << setw(30) << "Last 5 Places Visited:  ";
	colour_code(h, 7);
	for (int i = 0; i < 5; i++)
	{
		getline(fin, place, '\n');
		cout << place << "    ";
	}
	cout << endl;

	fin.close();
}

void enterDetails(int command_Number, Plane **list_Of_Planes, Route *list_Of_Routes, Airport **list_Of_Airports, Person &Customer1, int numberOfRoutes)
{
	Show_Graph();
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

	int start_point_key = 0, end_point_key = 0, number_Of_Airports = 0;
	endl(2); endl(2);
	cout << "Enter flight takeoff location.(Use the associated key)"; endl(5);
	cin >> start_point_key; endl(2);

	ifstream fin("Creating Circuit.txt");
	if (!fin)
		file_opening_error();
	fin >> number_Of_Airports;
	fin.close();

	while ((start_point_key > number_Of_Airports || start_point_key < 1))		//check for valid input of airport
	{
		endl(1);
		cout << "Error I02: Input is out of Range.";
		destination_call(0);					//buzzer sound
		endl(2);
		cout << "Enter again."; endl(5);
		cin >> start_point_key;
		endl(2);
	}

	cout << "Enter flight destination location.(Use the associated key)"; endl(5);
	cin >> end_point_key;
	cout << endl;

	while ((end_point_key == start_point_key) || (end_point_key > number_Of_Airports || end_point_key < 1))
	{
		if (end_point_key == start_point_key)
		{
			endl(1);
			cout << "Error P01: Flight destination cannot be same as takeoff location.";
			destination_call(0);					//buzzer sound
			endl(2);
			cout << "Enter again."; endl(5);
			cin >> end_point_key;
		}
		if (end_point_key > number_Of_Airports || end_point_key < 1)
		{
			endl(1);
			cout << "Error I02: Input is out of Range.";
			destination_call(0);					//buzzer sound
			endl(2);
			cout << "Enter again."; endl(5);
			cin >> end_point_key;
			endl(2);
		}
	}

	show_flights();

	ifstream fin2("Creating Planes.txt");
	if (!fin2)
		file_opening_error();

	int number_Of_Planes = 0;
	fin2 >> number_Of_Planes;
	fin2.close();

	bool available = true;
	int num = 0;
	endl(2); endl(2);
	cout << "Enter The Number Of The Flight To Take."; endl(9);
	cin >> num;
	while ((num < 1 || num > number_Of_Planes) || !available)
	{
		endl(1);
		cout << "Error I02: Input is out of Range.";
		destination_call(0);					//buzzer sound
		endl(2);
		cout << "Enter again."; endl(9);
		cin >> num;
		if (num > 0 && num < number_Of_Planes)
		{
			if (get_random_number(10) == 1)			//probability for a plane being unavailable is 1 out of 10
			{
				available = false;
				endl(1);
				cout << "Error P03: This Plane Is Not In Proper Condition For Departure.";
				destination_call(0);					//buzzer sound
				endl(2);
				cout << "Please Select another flight."; endl(9);
				cin >> num;
			}
		}
	}

	char flight_call_sign[5] = { '\0' };
	for (int i = 0; i < 5; i++)
	{
		flight_call_sign[i] = list_Of_Planes[num - 1]->get_call_sign(i);
	}

	if (command_Number == 1)
	{
		bookAFlight(start_point_key, end_point_key, flight_call_sign, list_Of_Routes, list_Of_Planes, list_Of_Airports, Customer1, numberOfRoutes); endl(2);
		flightDetails(start_point_key, end_point_key, list_Of_Planes[num - 1]->get_flightRate(), list_Of_Routes, list_Of_Planes, list_Of_Airports, numberOfRoutes);
	}
	else
		flightDetails(start_point_key, end_point_key, list_Of_Planes[num - 1]->get_flightRate(), list_Of_Routes, list_Of_Planes, list_Of_Airports, numberOfRoutes);
}

void Show_Menu(Plane **list_Of_Planes, Route *list_Of_Routes, Airport **list_Of_Airports, Person &Customer1, int numberOfRoutes)
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

	int command_Number = -1;
	while (command_Number != 0)		//repeat while loop until input != 0(option for exit)
	{
		endl(2);endl(2);
		cout << "Press 1 to Book a Flight."; endl(2);
		cout << "Press 2 for Flight Details."; endl(2);
		cout << "Press 3 to view your travel history."; endl(2);
		cout << "Press 0 to exit."; endl(9);
		cin >> command_Number;

		while (command_Number != 0 && command_Number != 1 && command_Number != 2 && command_Number != 3)		//check for valid input
		{
			endl(1);
			cout << "Error I01/I02: Input is out of range. Enter again.";
			destination_call(0);					//buzzer sound
			endl(9);
			cout << "Press 0, 1, 2 or 3."; endl(2);
			cin >> command_Number;
		}

		endl(2);
		if (command_Number == 1 || command_Number == 2)
			enterDetails(command_Number, list_Of_Planes, list_Of_Routes, list_Of_Airports, Customer1, numberOfRoutes);		//proceed to flight information sector
		else if (command_Number == 3)
			viewHistory();									//proceed to view your travel history
		else
			leave();										//proceed to leave program

		endl(5);
		cout << "Press any key to proceed."; endl(2);
		_getch(); endl(2);
	}
}

Person createAccount()		//function to create account
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	Person Customer1;
	string temp_name, temp_cnic = "\0";
	int temp_age = 0;

	cout << endl;  endl(3);
	cout << "Creating account."; endl(1);
	cout << "Enter your name: ";
	cin.ignore();
	colour_code(h, 3);
	getline(cin, temp_name, '\n');
	Customer1.set_name(temp_name); endl(1);

	cout << "Enter age: ";
	colour_code(h, 3);
	cin >> temp_age;

	while (temp_age < 18)
	{
		colour_code(h, 1);
		if (temp_age > 0)
		{
			endl(1);
			cout << "You are not old enough to use our services."; endl(1);
		}
		cout << "I01 : Input Is Invalid.";
		destination_call(0);					//buzzer sound
		endl(1); endl(1);
		cout << "Please enter again."; endl(3);
		cin >> temp_age; endl(3);
	}

	Customer1.set_age(temp_age); endl(1);

	//check for input to be integer only

	cout << "Enter CNIC: ";
	colour_code(h, 3);
	getline(cin, temp_cnic);
	getline(cin, temp_cnic);

	while (temp_cnic.length() != 13)
	{
		endl(1);
		cout << "I01 : Input Is Invalid.";
		destination_call(0);					//buzzer sound
		endl(1);
		cout << "Please enter again."; endl(3);
		getline(cin, temp_cnic); endl(3);
	}
	cin.clear();

	Customer1.set_CNIC(temp_cnic); endl(3); endl(3);

	fstream fin("Existing Account Details.txt", ios::out);
	if (!fin)
		file_opening_error();

	cout << "Your account has been created."; endl(9); endl(9);

	cout << "Account details:";  endl(1);
	cout << "Name: ";
	colour_code(h, 3); 
	cout << Customer1.get_name();  endl(1);
	fin << Customer1.get_name();
	fin << endl;

	cout << "CNIC: ";
	colour_code(h, 3);
	cout << Customer1.get_CNIC(); endl(1);
	fin << Customer1.get_CNIC();
	fin << endl;

	cout << "Age:  ";
	colour_code(h, 3);
	cout << Customer1.get_age(); endl(3);
	fin << Customer1.get_age();

	return Customer1;
}

Person UseExistingAccount()
{
	ifstream fin("Existing Account Details.txt");
	if (!fin)
		file_opening_error();

	Person Customer1;
	char a = NULL;
	fin >> a;
	if (!fin.eof())
	{
		fin.close();
		ifstream findum("Existing Account Details.txt");
		if (!findum)
			file_opening_error();

		string temp_name, temp_cnic = "\0";
		int temp_age;

		getline(findum, temp_name);
		Customer1.set_name(temp_name);

		getline(findum, temp_cnic);
		Customer1.set_CNIC(temp_cnic);

		findum >> temp_age;
		Customer1.set_age(temp_age);

		findum.close();			//close file

		return Customer1;       //return person created
	}
	else
	{
		HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
		colour_code(h, 4);

		cout << "Error F02: File Is Empty; You Do Not Have An Account."; endl(4);
		destination_call(0);					//buzzer sound
		endl(4);
		cout << "Please Proceed To Create An Account."; endl(4);

		Customer1 = createAccount();
		return Customer1;
	}
	return Customer1;
}

Person Membership()
{
	_getch();
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	int instruction_Number;
	colour_code(h, 6);

	cout << "_____________________________________________________________________________________________________________"; endl(1); endl(9);
	cout << "Press 1 if you already have an account."; endl(9);
	cout << "Press 2 to create an account."; endl(9);
	cin >> instruction_Number;

	while (instruction_Number != 1 && instruction_Number != 2)
	{
		endl(1);
		cout << "Error I01/I02: Input is out of range. Enter again.";
		destination_call(0);					//buzzer sound
		endl(9);
		cin >> instruction_Number;
	}

	if (instruction_Number == 1)
	{
		Person Customer1 = UseExistingAccount(); endl(3);		//retrieve account details

		cout << "Your Account Details:"; endl(1);
		cout << "Name: ";
		colour_code(h, 3);
		cout << Customer1.get_name(); endl(1);
		cout << "Age:  ";
		colour_code(h, 3);
		cout << Customer1.get_age(); endl(1);
		cout << "CNIC: ";
		colour_code(h, 3);
		cout << Customer1.get_CNIC(); endl(6);
		cout << "_____________________________________________________________________________________________________________";  endl(1);

		return Customer1;				//return person created
	}
	else
	{
		Person Customer1 = createAccount();				//create user account

		colour_code(h, 1);
		cout << "__________________________________________________________________________________________________________"; endl(1);

		return Customer1;				//return person created
	}
}

Plane **Create_Planes()
{
	ifstream fin("Creating Planes.txt");
	if (!fin)
		file_opening_error();

	int numOfFlights = 0;
	fin >> numOfFlights;						//extract number of flights available

	Plane **list_Of_Planes;
	list_Of_Planes = new Plane*[numOfFlights];
	for (int i = 0; i < numOfFlights; i++)
	{
		char temp_name[100] = { '\0' };			//to store name of plane
		char temp_model[50] = { '\0' };			//to store model of plane
		char temp_call_sign[5] = { '\0' };		//to store call sign of flight
		double temp_flight_rate = 0.0;			//to store rate of flight
		int temp_plane_capacity = 0;			//to store plane capacity

		fin.ignore();
		fin.getline(temp_name, 99, ',');		//extract name of plane
		fin.getline(temp_model, 49, ',');		//extract model of plane
		fin.ignore(1);							//ignore comma
		for (int j = 0; j < 5; j++)
		{
			fin >> temp_call_sign[j];			//extract 5 characters call sign
		}
		fin.ignore(2);							//ignore comma and space
		fin >> temp_flight_rate;				//extract rate of flight
		fin.ignore(2);							//ignore comma and space
		fin >> temp_plane_capacity;				//extract palne capacity

		list_Of_Planes[i] = nullptr;
		list_Of_Planes[i] = new Plane((string)temp_name, (string)temp_model, temp_call_sign, temp_flight_rate, temp_plane_capacity);		//create plane
	}
	fin.close();								//close file

	return list_Of_Planes;						//return array of planes
}

Route *Create_Routes(Airport **list_Of_Airports, int numOfAirports, int numOfLinks)
{
	Route *list_Of_Routes;
	list_Of_Routes = new Route[numOfLinks];
	int index_for_Routes = -1;
	double dist = 0.0;
	long double latitude1 = 0.0, latitude2 = 0.0, longitude1 = 0.0, longitude2 = 0.0;

	//uses values of upper triangular matrix
	for (int i = 0; i < numOfAirports; i++)							//traversal through array of airports
	{
		for (int j = 0; j <(numOfAirports - i - 1); j++)			//traversal through adjacency list of each airport
		{
			if (list_Of_Airports[i]->get_adjacency_value(j))		//if value in adjacency matrix is 1
			{
				index_for_Routes++;
				list_Of_Routes[index_for_Routes].set_point1(list_Of_Airports[i]);			//one end of the route is set to the airport at position 'i' in the array of airports
				list_Of_Routes[index_for_Routes].set_point2(list_Of_Airports[i + j + 1]);	//second end of the route is set to the airport at postion 'i+j+1' in the airports
				
				latitude1 = list_Of_Airports[i]->get_latitude();
				longitude1 = list_Of_Airports[i]->get_longitude();
				latitude2 = list_Of_Airports[i + j + 1]->get_latitude();
				longitude2 = list_Of_Airports[i + j + 1]->get_longitude();
				dist = Haversine_Formula(latitude1, longitude1, latitude2, longitude2);
				list_Of_Routes[index_for_Routes].set_distance(dist);						//length of route is set
			}
		}
	}

	return list_Of_Routes;											//return array Airport routes
}

Airport **Create_Circuit(Route *&list_Of_Routes, int &numberOfRoutes)		//creates airports and links between them
{
	ifstream fin("Creating Circuit.txt"), fin2("Adjacency Matrix.txt");
	if (!fin)
		file_opening_error();
	if (!fin2)
		file_opening_error();

	int numOfAirports = 0;
	fin >> numOfAirports;							//extract total number of airports

	int temp_key;									//to store key of airport
	char temp_code[5] = { '\0' };					//to store code
	char temp_location[51] = { '\0' };				//to store location of airport
	char temp_country[51] = { '\0' };				//to store country of airport
	char temp_name[100] = { '\0' };					//to store name of airport
	long double temp_lat;							//to store latitude coordinate
	long double temp_lon;							//to store longitude coordinate
	int temp_numOfConnections;						//to store number of linked airports
	bool temp_isLinked = false;						//to store each adjacency value
	numberOfRoutes = 0;								//to store total number of routes available

	Airport **list_Of_Airports = nullptr;
	list_Of_Airports = new Airport*[numOfAirports];
	for (int i = 0; i < numOfAirports; i++)
	{
		fin >> temp_key;							//extract key number
		fin.ignore(2);								//ignore comma
		fin.getline(temp_code, 4, ',');				//extract code of flight
		fin.getline(temp_location, 50, ',');		//extract location of airport
		fin.getline(temp_country, 50, ',');			//extract country of airport
		fin.getline(temp_name, 99, ',');			//extract name of airport
		fin.ignore(1);								//ignore comma and space
		fin >> temp_lat;							//extract latitude coordinate
		fin.ignore(2);								//ignore comma and space
		fin >> temp_lon;							//extract longitude coordinate
		fin.ignore(2);								//ignore comma and space
		fin >> temp_numOfConnections;				//extract number of linked airports
		list_Of_Airports[i] = nullptr;
		list_Of_Airports[i] = new Airport(temp_key, temp_code, (string)temp_location, (string)temp_country, (string)temp_name, temp_numOfConnections, temp_lat, temp_lon);	//create airport
		vector<bool> arrOfConnections;				//to store adjacency list
		int j = 0;

		for (j = 0; j <= i; j++)					//for the airport being constructed
		{
			fin2 >> temp_isLinked;					//fill up adjacency list of the airport
			if (temp_isLinked == true)				//if route exists, increment in total number of routes
			{
				list_Of_Airports[j]->add_neighbour_to_vector_of_connections(list_Of_Airports[i]);		//add this Airport to Neighbour of Airport already existing
				list_Of_Airports[i]->add_neighbour_to_vector_of_connections(list_Of_Airports[j]);
				numberOfRoutes++;
			}
		}
		//this for loop reads values of upper triangular matrtix, used to make Neighours with Airports

		for (int k = numOfAirports - 1; k >= j; k--)
		{
			fin2 >> temp_isLinked;
			arrOfConnections.push_back(temp_isLinked);
		}
		//this for loop reads values of lower triangular matrtix, used to create Routes between Airports

		list_Of_Airports[i]->set_vector_of_connections(arrOfConnections);	//set vector list of all Neighbours of this Airport
	}

	fin2.close();									//close file
	fin.close();									//close file

	list_Of_Routes = Create_Routes(list_Of_Airports, numOfAirports, numberOfRoutes);

	return list_Of_Airports;						//return array of airports
}

void Welcome()
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

	endl(7);
	cout << setw(70) << "WELCOME TO AERO MANAGEMENT"; endl(7);		//print in middle of screen
	cout << setw(70) << "A FLIGHT OPERATION SERVICE";				//print in middle of screen
	PlaySound("Welcome to Air O Management", NULL, SND_SYNC);
	//first paramter: name of file, second paramter: NULL, third parameter: asynchronous/synchronous sound

	endl(1);
	cout << "Press a key to show all air routes."; endl(5);
	PlaySound("Press a key to show all air routes", NULL, SND_SYNC);
	_getch();
}

void CopyRights()
{
	HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
	colour_code(h, 7);

	cout << setw(60) << " " << "Project by:"; endl(7);
	cout << setw(60) << " " << "BASSAM ALI RAZA BHATTI (18L-0963)"; endl(7);
	cout << setw(60) << " " << "MOHAMMAD AHMED IRFAN   (18L-0979)"; endl(7);
	cout << setw(60) << " " << "UMAR IQBAL             (18L-1156)"; endl(5); endl(5);
}

int main()
{
	Welcome();											//introduction
	Show_Graph();										//show the map of International Airlines System being followed in two dimensional space

	Route *list_Of_Routes;								//create pointer to array of routes between airports
	int numberOfRoutes = 0;
	Airport **list_Of_Airports;							//create double pointer to array of airports
	list_Of_Airports = Create_Circuit(list_Of_Routes, numberOfRoutes);						//proceed to create airports and links between them

	Plane **list_Of_Planes;								//create double pointer to array of planes
	list_Of_Planes = Create_Planes();					//proceed to create planes

	Person Customer1;									//Human of type Person created
	Customer1 = Membership();							//proceed to create User's identity

	Show_Menu(list_Of_Planes, list_Of_Routes, list_Of_Airports, Customer1, numberOfRoutes);	//proceed to show User Menu

	CopyRights();

	system("pause");
	return 0;
}