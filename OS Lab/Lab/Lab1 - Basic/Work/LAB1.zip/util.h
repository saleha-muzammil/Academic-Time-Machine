#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>

void removeNonAlphabets(char* inputFileName, char* outputFileName);
